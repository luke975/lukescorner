MICRO:BIT V2 ONLY!!!
This Micro:bit "Game Engine" is a dot that you can move around the screen.

Flaws:
-When you go out of bounds, game freezes

Controls:
A = Up
B = Move Right
A+B = Move Left
Micro:bit Logo tap = Down

These controls move the dot.

To put game on your Micro:bit, drag & drop game onto your Micro:bit when plugged into PC

Enjoy!

MMXXV Mowjayng StowdiO's, a group of people dedicated to making games in Minecraft